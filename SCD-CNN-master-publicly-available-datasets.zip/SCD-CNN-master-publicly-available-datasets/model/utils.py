import numpy as np
from torch.nn import L1Loss, MSELoss
import torch
import scipy.io as io
from collections import OrderedDict
import threading

def _loss(x,y_out):
    #loss = torch.nn.MSELoss(y_out, x-x_noisy).
    """shape = x.shape
    x = torch.reshape(x, shape=(shape[0], shape[2], shape[3]))
    x_noisy = torch.reshape(x_noisy, shape=(shape[0], shape[2], shape[3]))
    y_out = torch.reshape(y_out, shape=(shape[0], shape[2], shape[3]))"""
    loss = L1Loss()(x, y_out)
    #loss = torch.norm(y_out-(x-x_noisy), p=2)
    #loss = torch.norm(y_out-x, p=2)
    #loss = tf.norm(y_out-x, ord='euclidean')

    return loss

class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self

def _np_noise(volume,noise_level):
    shape = volume.shape
    noise = np.random.normal(0.0, noise_level, shape).astype(np.float32)
    noise_simulated_data = volume + noise
    noise_simulated_data = np.clip(noise_simulated_data, 0, 1)
    return noise_simulated_data

def torch_noise(volume,noise_level=0.098):
    shape = volume.shape
    noise = torch.normal(0.0, noise_level, size=shape)
    noise_simulated_data = volume + noise
    #noise_simulated_data = np.clip(noise_simulated_data, 0, 1)
    return noise_simulated_data

def gauss_stripe_noise(img):
    img = torch_noise(img)
    # img_copy = torch.clone(img)
    # add stripe
    X, Y, B, H, W = img.shape
    # init
    min_amount, max_amount = 0.05, 0.15
    num_band = 1 / 3
    # get band
    pos = 0
    all_bands = np.random.permutation(range(B))
    num_band = int(np.floor(num_band * B))
    bands = all_bands[pos:pos + num_band]
    num_stripe = np.random.randint(np.floor(min_amount * W), np.floor(max_amount * W), len(bands))
    for i, n in zip(bands, num_stripe):
        loc = np.random.permutation(range(W))
        loc = loc[:n]
        stripe = torch.rand(size=(64,1)) * 0.5 - 0.25
        img[:, :, i, :, loc] -= stripe
    # aaa = torch.eq(img, img_copy)
    # bbb = 0
    # aaa = torch.squeeze(aaa, dim=1)
    # for m in range(8):
    #     for g in range(24):
    #         for o in range(64):
    #             for p in range(64):
    #                 if aaa[m, g, o, p]:
    #                     pass
    #                 else:
    #                     bbb += 1
    # print("--------------------------------")
    return img

def gauss_impulse_noise(img):
    img = torch_noise(img)
    # add stripe
    X, Y, B, H, W = img.shape
    # init
    amounts = np.array([0.1, 0.3, 0.5, 0.7])

    s_vs_p = 0.5
    num_band = 1 / 3
    # get band
    pos = 0
    all_bands = np.random.permutation(range(B))
    num_band = int(np.floor(num_band * B))
    bands = all_bands[pos:pos + num_band]
    def add_noise(image, amount, salt_vs_pepper):
        # out = image.copy()
        out = torch.squeeze(image, dim=1)
        p = amount
        q = salt_vs_pepper
        for i in range(out.shape[0]):
            flipped = np.random.choice([True, False], size=out[i].shape,
                                       p=[p, 1 - p])
            salted = np.random.choice([True, False], size=out[i].shape,
                                      p=[q, 1 - q])
            peppered = ~salted
            out[i][flipped & salted] = 1
            out[i][flipped & peppered] = 0
        out = torch.unsqueeze(out, dim=1)
        return out
    bwamounts = amounts[np.random.randint(0, len(amounts), len(bands))]
    for i, amount in zip(bands, bwamounts):
        add_noise(img[:,:, i, ...], amount=amount, salt_vs_pepper=s_vs_p)
    return img


def torch_blindnoise(volume, min_sigma, max_sigma):
    shape = volume.shape
    noise = np.random.randn(shape) * np.random.uniform(min_sigma, max_sigma) / 255
    noise_simulated_data = volume + torch.from_numpy(noise)
    #noise_simulated_data = np.clip(noise_simulated_data, 0, 1)
    return noise_simulated_data

def merged_patch(clean_image_list,noise_image_list,hsi_image_list, shape=(200, 200, 191), patch=20):
    clean_image = np.zeros(shape, dtype=np.float32)
    noise_image = np.zeros(shape, dtype=np.float32)
    hsi_image = np.zeros(shape, dtype=np.float32)
    num_patches = int(shape[0] / patch)
    for x in range(0, num_patches):
        for y in range(0, num_patches):
            for z in range(0, shape[2]):
                clean_image[x * patch:x * patch + patch, y * patch:y * patch + patch, z] = \
                    clean_image_list[x*num_patches*shape[2]+ y*shape[2] + z]
                noise_image[x * patch:x * patch + patch, y * patch:y * patch + patch, z] = \
                    noise_image_list[x*num_patches*shape[2]+ y*shape[2] + z]
                hsi_image[x * patch:x * patch + patch, y * patch:y * patch + patch, z] = \
                    hsi_image_list[x*num_patches*shape[2]+ y*shape[2] + z]
    return clean_image, noise_image, hsi_image

def save_output(data, path, train_type):
    mdic = {"data": data}
    io.savemat(path + "/hsi_"+train_type+".mat", mdic)

def load_checkpoint(model, checkpoint):
    try:
        model.load_state_dict(checkpoint["model_state_dict"])
    except:
        state_dict = checkpoint["model_state_dict"]
        new_state_dict = OrderedDict()
        for k, v in state_dict.items():
            name = k[7:] if 'module.' in k else k
            new_state_dict[name] = v
        model.load_state_dict(new_state_dict)

def load_checkpoint2(model, checkpoint):
    try:
        model.load_state_dict(checkpoint["net"])
    except:
        state_dict = checkpoint["net"]
        new_state_dict = OrderedDict()
        for k, v in state_dict.items():
            name = k[7:] if 'module.' in k else k
            new_state_dict[name] = v
        model.load_state_dict(new_state_dict)

def count_param(model):
    param_count = 0
    for param in model.parameters():
        param_count += param.view(-1).size()[0]
    return param_count