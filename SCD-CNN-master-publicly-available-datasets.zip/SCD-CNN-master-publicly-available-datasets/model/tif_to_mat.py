import scipy.io as sio
import skimage.io
import numpy as np
import spectral
import os

def feature_max_norm(data):
    '''
    Args:
        data: image's pixel

    Returns:
        standardized data
    '''
    data = data / np.max(data)
    return data

# 读取tif文件并将其存储为numpy数组
# image = skimage.io.imread('E:/PyDome/SM-CNN-master/datasets/PU/DC.tif')
image = sio.loadmat('E:/PyDome/SCD-CNN-master/model/dataSet/IP/Indian_pines.mat')['indian_pines']
# guiyihua
image = image.transpose((2,0,1))
c, h, w = image.shape
data = np.empty((0, h, w), dtype=np.float32)
for i in range(c):
    normal_img = feature_max_norm(image[i])
    data_np = normal_img[np.newaxis, :, :]  # 加一个维度
    data = np.concatenate((data, data_np), axis=0)
data = data.transpose((1,2,0))
# 保存为mat文件
sio.savemat(r'E:\PyDome\SCD-CNN-master\datasets\IP\IP.mat', {'data': data})
# 显示图像
# 数据集的光栅显示
# spectral.save_rgb("WDC_rgb.jpg",data,[30])