import torch
import torch.nn as nn
import torch.nn.functional as F
class DeformableConv3D(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0):
        super(DeformableConv3D, self).__init__()
        self.offset_conv = nn.Conv3d(in_channels, 3*kernel_size*kernel_size*kernel_size, kernel_size, stride, padding)
        self.modulator_conv = nn.Conv3d(in_channels, kernel_size*kernel_size*kernel_size, kernel_size, stride, padding)
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size, stride, padding)
        self.kernel_size = kernel_size
        self.padding = padding
    def forward(self, x):
        offset = self.offset_conv(x)
        modulator = torch.sigmoid(self.modulator_conv(x))
        return F.conv3d(x, self.conv.weight, padding=self.padding, stride=self.conv.stride, dilation=self.conv.dilation) + \
               self.deformable_conv3d(x, offset, modulator)
    def deformable_conv3d(self, x, offset, modulator):
        n, c, d, h, w = x.size()
        kd, kh, kw = self.kernel_size, self.kernel_size, self.kernel_size
        dd, dh, dw = self.conv.stride
        pad_d, pad_h, pad_w = self.padding, self.padding, self.padding
        zz = torch.arange(d).view(1, -1).repeat(h, w, 1).type_as(x)  # [h, w, d]
        yy = torch.arange(h).view(-1, 1).repeat(1, w, d).type_as(x)  # [h, w, d]
        xx = torch.arange(w).view(-1, 1, 1).repeat(h, d, 1).type_as(x)  # [h, w, d]
        aaa = 0.5 * (offset[:, :kd * kh * kw].view(n, kd, kh, kw, d, h, w) * modulator[:, :kd * kh * kw].view(n, kd, kh, kw, d, h, w)).sum(dim=1).view(n, 1, 1, 1, d, h, w)
        zz = zz + 0.5 * (offset[:, :kd * kh * kw].view(n, kd, kh, kw, d, h, w) * modulator[:, :kd * kh * kw].view(n, kd, kh, kw, d, h, w)).sum(dim=1).view(n, 1, 1, 1, d, h, w)
        yy = yy + 0.5 * (offset[:, kd * kh * kw:2*kd * kh * kw].view(n, kd, kh, kw, d, h, w) * modulator[:, kd * kh * kw:2*kd * kh * kw].view(n, kd, kh, kw, d, h, w)).sum(dim=1).view(n, 1, 1, 1, d, h, w)
        xx = xx + 0.5 * (offset[:, 2*kd * kh * kw:].view(n, kd, kh, kw, d, h, w) * modulator[:, 2*kd * kh * kw:].view(n, kd, kh, kw, d, h, w)).sum(dim=1).view(n, 1, 1, 1, d, h, w)
        zz = zz.clamp(0, d - 1)
        yy = yy.clamp(0, h - 1)
        xx = xx.clamp(0, w - 1)
        z1 = zz.floor()
        z2 = (zz + 1).floor()
        y1 = yy.floor()
        y2 = (yy + 1).floor()
        x1 = xx.floor()
        x2 = (xx + 1).floor()
        wa = ((x2 - xx) * (y2 - yy) * (z2 - zz)).view(n, kd, kh, kw, d, h, w)
        wb = ((xx - x1) * (y2 - yy) * (z2 - zz)).view(n, kd, kh, kw, d, h, w)
        wc = ((x2 - xx) * (yy - y1) * (z2 - zz)).view(n, kd, kh, kw, d, h, w)
        wd = ((xx - x1) * (yy - y1) * (z2 - zz)).view(n, kd, kh, kw, d, h, w)
        we = ((x2 - xx) * (y2 - yy) * (zz - z1)).view(n, kd, kh, kw, d, h, w)
        wf = ((xx - x1) * (y2 - yy) * (zz - z1)).view(n, kd, kh, kw, d, h, w)
        wg = ((x2 - xx) * (yy - y1) * (zz - z1)).view(n, kd, kh, kw, d, h, w)
        wh = ((xx - x1) * (yy - y1) * (zz - z1)).view(n, kd, kh, kw, d, h, w)
        z1 = z1.clamp(0, d - 1).long()
        z2 = z2.clamp(0, d - 1).long()
        y1 = y1.clamp(0, h - 1).long()
        y2 = y2.clamp(0, h - 1).long()
        x1 = x1.clamp(0, w - 1).long()
        x2 = x2.clamp(0, w - 1).long()
        z1 = z1.unsqueeze(dim=1).unsqueeze(dim=5).unsqueeze(dim=6).repeat(1, c, 1, 1, 1, h, w)
        z2 = z2.unsqueeze(dim=1).unsqueeze(dim=5).unsqueeze(dim=6).repeat(1, c, 1, 1, 1, h, w)
        y1 = y1.unsqueeze(dim=1).unsqueeze(dim=5).unsqueeze(dim=3).repeat(1, c, 1, 1, d, 1, w)
        y2 = y2.unsqueeze(dim=1).unsqueeze(dim=5).unsqueeze(dim=3).repeat(1, c, 1, 1, d, 1, w)
        x1 = x1.unsqueeze(dim=1).unsqueeze(dim=5).unsqueeze(dim=4).repeat(1, c, 1, kd, 1, h, 1)
        x2 = x2.unsqueeze(dim=1).unsqueeze(dim=5).unsqueeze(dim=4).repeat(1, c, 1, kd, 1, h, 1)
        output = wa * x[:, :, z1, y1, x1] + \
                 wb * x[:, :, z1, y1, x2] + \
                 wc * x[:, :, z1, y2, x1] + \
                 wd * x[:, :, z1, y2, x2] + \
                 we * x[:, :, z2, y1, x1] + \
                 wf * x[:, :, z2, y1, x2] + \
                 wg * x[:, :, z2, y2, x1] + \
                 wh * x[:, :, z2, y2, x2]
        return output
class ActionRecognitionNetwork(nn.Module):
    def __init__(self, num_classes):
        super(ActionRecognitionNetwork, self).__init__()
        self.conv1 = DeformableConv3D(1, 20, kernel_size=3, stride=1, padding=1)
        self.conv2 = DeformableConv3D(64, 128, kernel_size=3, stride=1, padding=1)
        self.fc1 = nn.Linear(128 * 8 * 8 * 8, 256)
        self.fc2 = nn.Linear(256, num_classes)
    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool3d(x, kernel_size=2, stride=2)
        x = F.relu(self.conv2(x))
        x = F.max_pool3d(x, kernel_size=2, stride=2)
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x
# 测试示例
input = torch.randn(8, 1, 24, 64, 64)
model = ActionRecognitionNetwork(num_classes=10)
output = model(input)
print("Output shape:", output.shape)