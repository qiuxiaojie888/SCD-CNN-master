import os
import numpy as np
import torch
from scipy.io import savemat, loadmat
import skimage

# 切分数据
def crop_img(data):
    data = data.transpose((2,0,1))
    crop_data = np.empty((0, 145, 145), dtype=np.float32)
    for i in range(data.shape[0]):
        data_c = data[i][0:145, 0:145]
        data_np = data_c[np.newaxis, :, :]  # 加一个维度
        crop_data = np.concatenate((crop_data, data_np), axis=0)
    return crop_data

if __name__ == '__main__':

    # 读取 mat
    images = loadmat(f'../datasets/WDC/valid/patch_1_801.mat')
    # 对图像进行裁剪
    data_crop = crop_img(data)
    # 添加噪声
    add_noise(data_crop, sigma=25)