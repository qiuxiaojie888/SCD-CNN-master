import torch
from torch import nn
from deform_conv_v2 import DeformConv2d
from einops import rearrange
import torch.nn.functional as F

# initialization
def init_weight(m):
    if type(m) == nn.Conv2d:
        nn.init.xavier_normal_(m.weight)
    elif type(m) == nn.Conv3d:
        nn.init.xavier_normal_(m.weight)

class GSAttention(nn.Module):
    """global spectral attention (GSA)

    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads
        bias (bool): If True, add a learnable bias to projection
    """

    def __init__(self, dim, num_heads=6, bias=False):
        super(GSAttention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, c, h, w = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=1)
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)
        out = (attn @ v)
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)
        out = self.project_out(out)
        return out

class MHSA3D(nn.Module):
    def __init__(self, channels=60, num_heads=1):
        super(MHSA3D, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(1, num_heads, 1, 1))

        self.qkv = nn.Conv3d(channels, channels * 3, kernel_size=(1, 1, 1), bias=False)
        self.qkv_conv = nn.Conv3d(channels * 3, channels * 3, kernel_size=(1, 3, 3), padding=(0, 1, 1), groups=channels * 3, bias=False)# 331
        self.project_out = nn.Conv3d(channels, channels, kernel_size=(1, 1, 1), bias=False)

    def forward(self, x):
        b, t, c, h, w = x.shape
        q, k, v = self.qkv_conv(self.qkv(x)).chunk(3, dim=1)

        q = q.reshape(b, self.num_heads, -1,  h * w * t)
        k = k.reshape(b, self.num_heads, -1,  h * w * t)
        v = v.reshape(b, self.num_heads, -1,  h * w * t)
        q, k = F.normalize(q, dim=-1), F.normalize(k, dim=-1)

        attn = torch.softmax(torch.matmul(q, k.transpose(-2, -1).contiguous()) * self.temperature, dim=-1)
        out = self.project_out(torch.matmul(attn, v).reshape(b, t, -1, h, w))
        return out

class SpatialConv(nn.Module):
    def __init__(self, in_channel=1, out_channel=20, depth=3):
        super(SpatialConv, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        # kernel_size=3
        layer3 = []
        layer3.append(DeformConv2d(inc=in_channel, outc=out_channel, kernel_size=3, padding=1, bias=False, modulation=True))
        layer3.append(nn.ReLU())
        for _ in range(depth-2):
            layer3.append(nn.Conv2d(in_channels=out_channel, out_channels=out_channel, kernel_size=3, padding=1, bias=False))
            layer3.append(nn.BatchNorm2d(out_channel))
            layer3.append(nn.ReLU())
        self.conv2d_3 = nn.Sequential(*layer3)
        # kernel_size=5
        layer5 = []
        layer5.append(DeformConv2d(inc=in_channel, outc=out_channel, kernel_size=5, padding=2, bias=False, modulation=True))
        layer5.append(nn.ReLU())
        for _ in range(depth-1):
            layer5.append(nn.Conv2d(in_channels=out_channel, out_channels=out_channel, kernel_size=5, padding=2, bias=False))
            layer5.append(nn.BatchNorm2d(out_channel))
            layer5.append(nn.ReLU())
        self.conv2d_5 = nn.Sequential(*layer5)
        # kernel_size=7
        layer7 = []
        layer7.append(DeformConv2d(inc=in_channel, outc=out_channel, kernel_size=7, padding=3, bias=False, modulation=True))
        layer7.append(nn.ReLU())
        for _ in range(depth-1):
            layer7.append(nn.Conv2d(in_channels=out_channel, out_channels=out_channel, kernel_size=7, padding=3, bias=False))
            layer7.append(nn.BatchNorm2d(out_channel))
            layer7.append(nn.ReLU())
        self.conv2d_7 = nn.Sequential(*layer7)
        self.spectral_attn = GSAttention(dim=out_channel*3)
        self.ReLU = nn.ReLU()

    def forward(self, spatial_band):
        conv1 = self.conv2d_3(spatial_band)
        conv2 = self.conv2d_5(spatial_band)
        conv3 = self.conv2d_7(spatial_band)
        concat_volume = torch.cat([conv3, conv2, conv1], dim=1)
        output = self.ReLU(self.spectral_attn(concat_volume))
        return output

#3D spectral conv # 添加通道注意力机制和可变形卷积
class SpectralConv(nn.Module):
    def __init__(self,in_channel=1, out_channel=20, K=32, depth=3):
        super(SpectralConv, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.K = K
        # kernel_size=3
        layer3 = []
        layer3.append(nn.Conv3d(in_channels=in_channel, out_channels=out_channel, kernel_size=(K, 3, 3), padding=(0, 1, 1), bias=False))
        layer3.append(nn.ReLU())
        for _ in range(depth-2):
            layer3.append(nn.Conv3d(in_channels=out_channel, out_channels=out_channel, kernel_size=(1, 3, 3), padding=(0, 1, 1), bias=False))
            layer3.append(nn.BatchNorm3d(out_channel))
            layer3.append(nn.ReLU())
        self.conv3d_3 = nn.Sequential(*layer3)
        # kernel_size=5
        layer5 = []
        layer5.append(nn.Conv3d(in_channels=in_channel, out_channels=out_channel, kernel_size=(K, 5, 5), padding=(0, 2, 2), bias=False))
        layer5.append(nn.ReLU())
        for _ in range(depth - 1):
            layer5.append(nn.Conv3d(in_channels=out_channel, out_channels=out_channel, kernel_size=(1, 5, 5), padding=(0, 2, 2), bias=False))
            layer5.append(nn.BatchNorm3d(out_channel))
            layer5.append(nn.ReLU())
        self.conv3d_5 = nn.Sequential(*layer5)
        # kernel_size=7
        layer7 = []
        layer7.append(nn.Conv3d(in_channels=in_channel, out_channels=out_channel, kernel_size=(K, 7, 7), padding=(0, 3, 3), bias=False))
        layer7.append(nn.ReLU())
        for _ in range(depth - 1):
            layer7.append(nn.Conv3d(in_channels=out_channel, out_channels=out_channel, kernel_size=(1, 7, 7), padding=(0, 3, 3), bias=False))
            layer7.append(nn.BatchNorm3d(out_channel))
            layer7.append(nn.ReLU())
        self.conv3d_7 = nn.Sequential(*layer7)
        self.spatial_attn = MHSA3D(channels=out_channel*3)
        self.ReLU = nn.ReLU()

    def forward(self, spectral_vol):
        conv1 = self.conv3d_3(spectral_vol)
        conv2 = self.conv3d_5(spectral_vol)
        conv3 = self.conv3d_7(spectral_vol)
        concat_volume = torch.cat([conv3, conv2, conv1], dim=1)
        output = self.ReLU(self.spatial_attn(concat_volume))
        output = torch.squeeze(output, dim=2)
        return output

def param_free_norm(x, epsilon=1e-5) :
    x_var, x_mean = torch.var_mean(x, dim=[2, 3], keepdim=True)
    x_std = torch.sqrt(x_var + epsilon)
    return (x - x_mean) / x_std

# spectral self-modulation module
class ssmm(nn.Module):
    def __init__(self,in_channel, out_channel, k):
        super(ssmm, self).__init__()
        self.conv2_3 = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=(3, 3), padding=(1, 1), bias=False)
        self.conv2_5 = nn.Conv2d(in_channels=k, out_channels=out_channel, kernel_size=(5, 5), padding=(2, 2), bias=False)
        self.relu = nn.ReLU()

    def forward(self, x_init, adj_spectral):
        x = param_free_norm(x_init)
        tmp = self.conv2_5(adj_spectral)
        tmp = self.relu(tmp)
        noisemap_gamma = self.conv2_3(tmp)
        noisemap_beta = self.conv2_3(tmp)
        x = x * (1 + noisemap_gamma) + noisemap_beta
        return x

#spectral self-modulation residual block
class ssmrb(nn.Module):
    def __init__(self, in_channel, out_channel, k=32):
        super(ssmrb, self).__init__()
        self.conv2 = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=(3, 3), padding=(1, 1), bias=False)
        self.ssmm = ssmm(in_channel, out_channel, k)
        self.lrelu = nn.LeakyReLU(negative_slope=0.02)

    def forward(self, x_init, adj_spectral):
        x = self.ssmm(x_init, adj_spectral)
        x = self.lrelu(x)
        x = self.conv2(x)
        x = self.ssmm(x, adj_spectral)
        x = self.lrelu(x)
        x = self.conv2(x)
        return x + x_init

#conv block
class ConvBlock(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(ConvBlock, self).__init__()
        self.conv2d_1 = nn.Conv2d(in_channels=in_channel, out_channels=
                                  out_channel, kernel_size=(3, 3), padding=(1, 1), bias=False)
        self.conv2d_2 = nn.Conv2d(in_channels=out_channel, out_channels=
                                  out_channel, kernel_size=(3, 3), padding=(1, 1), bias=False)
        self.conv2d_4 = nn.Conv2d(in_channels=out_channel, out_channels=
                                  1, kernel_size=(3, 3), padding=(1, 1), bias=False)
        self.spectral_attn = GSAttention(dim=out_channel)
        self.ssmrb = ssmrb(out_channel, out_channel)
        self.relu = nn.ReLU()

    def forward(self,spectral_volume, volume):
        spectral_volume = torch.squeeze(spectral_volume, dim=1)
        conv1 = self.relu(self.conv2d_1(volume))
        conv2 = self.ssmrb(conv1, spectral_volume)
        conv2 = self.ssmrb(conv2, spectral_volume)
        conv3 = self.spectral_attn(conv2)
        conv4 = self.relu(conv3)
        return conv4

class DeepConv(nn.Module):
    def __init__(self, num_of_layers=15):
        super(DeepConv, self).__init__()
        kernel_size = 3
        padding = 1
        features = 60
        layers = []
        layers.append(nn.Conv2d(in_channels=features, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False))
        layers.append(nn.ReLU(inplace=True))
        for _ in range(num_of_layers-2):
            layers.append(nn.Conv2d(in_channels=features, out_channels=features, kernel_size=kernel_size, padding=padding, bias=False))
            layers.append(nn.BatchNorm2d(features))
            layers.append(nn.ReLU(inplace=True))

        layers.append(nn.Conv2d(in_channels=features, out_channels=1, kernel_size=kernel_size, padding=padding, bias=False))
        self.dncnn = nn.Sequential(*layers)

    def forward(self, x):
        residue = self.dncnn(x)
        return residue

#self-modulation CNN
class DDCNN(nn.Module):
    def __init__(self,num_3d_filters, num_2d_filters, num_conv_filters, K=32):
        super(DDCNN, self).__init__()
        self.spectral_conv = SpectralConv(in_channel=1, out_channel=num_3d_filters, K=K)
        self.spatial_conv = SpatialConv(in_channel=1, out_channel=num_2d_filters)
        self.conv_block = ConvBlock(in_channel=num_2d_filters*3+num_3d_filters*3, out_channel=num_conv_filters)
        self.deep_conv = DeepConv()

    def forward(self, spatial_band, spectral_volume):
        spatial_vol = self.spatial_conv(spatial_band)
        spectral_vol = self.spectral_conv(spectral_volume)
        for_conv_block = torch.cat([spatial_vol, spectral_vol], dim=1)
        conv_block_result = self.conv_block(spectral_volume, for_conv_block)
        residue = spatial_band - self.deep_conv(conv_block_result)
        return residue